%Fig. 5H
%Curve shift assay
%D2R WT, SV-III-130 

%Kinetic parameters 
k1=860000;
k2=0.01;
k3=5*10^6;
kn1=0.007;
kn2=0;
kn3=0.17;
DA=10^-7;
L=0;

param=[k1 k2 k3 kn1 kn2 kn3 DA L]

%1 �M DA - reference
end1=35;
tspan=0:end1;
tic
[time,y] = ode45(@(t,y) fourstate(t,y,param),tspan,y0);
toc
v1=y(:,2);
y1=y(end,:);

disp(y1);


%Curve shift assay
for i = 1:6
j = 0
param1=[860000 1/100 5*10^6 0.007 0 0.17 10^-(10-i) j];     
end1=600;
tspan=0:end1;
tic
[time,y] = ode45(@(t,y) fourstate(t,y,param1),tspan,y0);
toc
d1{i}=y(end,1);
d2{i}=y(end,2); %DA concentration-response
d3{i}=y(end,3);
d4{i}=y(end,4);
end

%Curve shift assay
for i = 1:6
       for j = 1:4
    param1=[860000 1/100 5*10^6 0.007 0 0.17 10^-(10-i) 10^-(10-j)];
        
end1=600;
tspan=0:end1;
tic
[time,y] = ode45(@(t,y) fourstate(t,y,param1),tspan,y0);
toc
%v{i,j}=y(:,2);
e1{i,j}=y(end,1);
e2{i,j}=y(end,2); %DA concentration-response in the presence of SV-III-132
e3{i,j}=y(end,3);
e4{i,j}=y(end,4);
    end
end


function ddt = fourstate(t,y,param)

k1=param(1);
k2=param(2);
k3=param(3);
kn1=param(4);
kn2=param(5);
kn3=param(6);
DA=param(7);
L=param(8);

ddt=[+y(2)*kn3+y(3)*kn1-y(1)*((k1*L)+(k3*DA))
    +y(1)*(k3*DA)-y(2)*kn3
    +y(1)*(k1*L)+y(4)*kn2-y(3)*(kn1+k2)
    +y(3)*k2-y(4)*kn2];
end