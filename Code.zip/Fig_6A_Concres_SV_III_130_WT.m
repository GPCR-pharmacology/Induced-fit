%Fig. 6A
%Concentration-response
%D2R WT, SV-III-130 

%Kinetic parameters 
k1=860000;
k2=0.01;
k3=5*10^6;
kn1=0.007;
kn2=0;
kn3=0.17;
DA=10^-7;
L=0;

param=[k1 k2 k3 kn1 kn2 kn3 DA L]


%100 nM DA
end1=45;
tspan=0:end1;
[time,y] = ode45(@(t,y) fourstate(t,y,param),tspan,y0);
v1=y(:,2);
y1=y(end,:);
disp(y1);

%3 nM SWR-1-11/100 nM DA
param(7)=100*10^-9;
param(8)=3*10^-9;
end2=100;%125;
tspan=0:end2;
[time,y] = ode45(@(t,y) fourstate(t,y,param),tspan,y1);
v2=y(:,2);
y2=y(end,:);
disp(y2);

%30 nM SWR-1-11/100 nM DA
param(8)=30*10^-9;
end3=100;%125;
tspan=0:end2;
[time,y] = ode45(@(t,y) fourstate(t,y,param),tspan,y1);
v3=y(:,2);
y3=y(end,:);
disp(y3);

%300 nM SWR-1-11/100 nM DA
param(8)=300*10^-9;
end4=100;%125;
tspan=0:end2;
[time,y] = ode45(@(t,y) fourstate(t,y,param),tspan,y1);
v4=y(:,2);
y4=y(end,:);
disp(y4);

%3000 nM SWR-1-11/100 nM DA
param(8)=3000*10^-9;
end5=100;%125;
tspan=0:end2;
[time,y] = ode45(@(t,y) fourstate(t,y,param),tspan,y1);
v5=y(:,2);
y5=y(end,:);
disp(y5);

%Washout
param(7)=0;
param(8)=0;
end6=60;
tspan=0:end4;
[time,y] = ode45(@(t,y) fourstate(t,y,param),tspan,y3);
v6=y(:,2);
y6=y(end,:);
disp(y6);

v=[v1' v2' v3' v4' v5' v6'];
u=-v;
urec=-v3;
plot(-v)

function ddt = fourstate(t,y,param)

k1=param(1);
k2=param(2);
k3=param(3);
kn1=param(4);
kn2=param(5);
kn3=param(6);
DA=param(7);
L=param(8);

ddt=[+y(2)*kn3+y(3)*kn1-y(1)*((k1*L)+(k3*DA))
    +y(1)*(k3*DA)-y(2)*kn3
    +y(1)*(k1*L)+y(4)*kn2-y(3)*(kn1+k2)
    +y(3)*k2-y(4)*kn2];
end