%Fig. 5F
%Response recovery 
%D2R WT, SV-III-130, 100 �M DA for recovery
%prolonged antagonist application, 400 s

%Kinetic parameters 
k1=860000;
k2=0.01;
k3=5*10^6;
kn1=0.007;
kn2=0;
kn3=0.17;
DA=10^-6;
L=0;

param=[k1 k2 k3 kn1 kn2 kn3 DA L]

%Initial values (unoccupied receptor)
y0=[1;0;0;0];

%Sequential applications
%1 �M DA
end1=45;
tspan=0:end1;
[time,y] = ode45(@(t,y) fourstate(t,y,param),tspan,y0);
v1=y(:,2);
y1=y(end,:);
disp(y1);

%1 �M SV-III-130/1 �M DA
param(8)=1*10^-6; %1 �M SV-III-130
end2=400; %400 s antagonist application
tspan=0:end2;
[time,y] = ode45(@(t,y) fourstate(t,y,param),tspan,y1);
v2=y(:,2);
y2=y(end,:);
disp(y2);

%100 �M DA 
param(7)=1*10^-4; %100 �M DA
param(8)=2*10^-8; %2% residual ligand accumulation
end3=420;
tspan=0:end3;
[time,y] = ode45(@(t,y) fourstate(t,y,param),tspan,y2);
v3=y(:,2);
y3=y(end,:);
disp(y3);

%Washout 
param(7)=0;
param(8)=0;
end4=60;
tspan=0:end4;
[time,y] = ode45(@(t,y) fourstate(t,y,param),tspan,y3);
v4=y(:,2);
y4=y(end,:);
disp(y4);


%Plot of time course
v=[v1' v2' v3' v4'];
u=-v;
urec=-v3;
plot(-v)


%Function for state transitions
%(With versions prior to 2016b, the function should be separated)

function ddt = fourstate(t,y,param)

k1=param(1);
k2=param(2);
k3=param(3);
kn1=param(4);
kn2=param(5);
kn3=param(6);
DA=param(7);
L=param(8);

ddt=[+y(2)*kn3+y(3)*kn1-y(1)*((k1*L)+(k3*DA))
    +y(1)*(k3*DA)-y(2)*kn3
    +y(1)*(k1*L)+y(4)*kn2-y(3)*(kn1+k2)
    +y(3)*k2-y(4)*kn2];
end